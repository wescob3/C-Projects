#pragma once
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
class Instruction {
public:
    vector<string> read_file(string);
    vector<string> my_instructions;
};
