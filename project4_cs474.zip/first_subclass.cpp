#include "first_subclass.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

vector<string> first_subclass::modify_instructions(vector<string> ttt_instructions){
   vector<string> mything;
    
    for(string & line : ttt_instructions){
         size_t pos = line.find(' '); //find location of word
            line.erase(0,pos);
        mything.push_back(line);
    }
   
    return mything;
}