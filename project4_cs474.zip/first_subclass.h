#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include "Instruction.h"
using namespace std;

class first_subclass : public Instruction{
    public:
    vector<string> modify_instructions(vector<string>);
};
