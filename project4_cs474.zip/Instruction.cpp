#include "Instruction.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

vector<string> Instruction::read_file(string fileName){
    // Open the File
    vector<string> vecOfStrs;
    ifstream in(fileName.c_str());
    // Check if object is valid
    if(!in)
    {
        cerr << "Cannot open the File : "<<fileName<<endl;
        return vecOfStrs;
    }
    string str;
    // Read the next line from File untill it reaches the end.
    while (getline(in, str))
    {
        // Line contains string of length > 0 then save it in vector
        if(str.size() > 0)
            vecOfStrs.push_back(str);
    }
    //Close The File
    in.close();
    return vecOfStrs;
}