//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Instruction.cpp"
#include "first_subclass.cpp"
#include "second_subclass.cpp"
#include <math.h> 
using namespace std;


int main(){
    vector<string> my_vector;
    Instruction my_pc_input;
    my_pc_input.my_instructions = my_pc_input.read_file("pc_input.txt");
    
    cout<<endl;
    cout<<"Welcome to my Calculator  "<<endl<<endl;
    cout<<"-------------------------- "<<endl<<endl;
    
   // cout<<" The isntructions: "<<endl;
   /* for(string & line : my_pc_input.my_instructions)
            cout<<line<<endl;*/
    
    //cout<<" The modified isntructions: "<<endl;
    first_subclass my_modified_input;
        
   /* for(string & thing : my_modified_input.modify_instructions(my_pc_input.my_instructions)){
            cout<<thing<<endl;
    }*/
    
    
        second_subclass mydata_object;
    //Getting user input
    string user_input;
    while(true){
        cout<<"--------------------------------------------------------"<<endl;
        cout<<" Enter a command to proceed choose from {r , s, x } : "<<endl;
        cin>>user_input;
        
        if(user_input[0]=='r'){
            cout<<"You entered r "<<endl;
            mydata_object.execute_instructions(my_modified_input.modify_instructions(my_pc_input.my_instructions), user_input);
          
        }
        else if(user_input[0]=='s'){
            cout<<"You entered s "<<endl;
             mydata_object.execute_instructions(my_modified_input.modify_instructions(my_pc_input.my_instructions), user_input);
        }
        else if(user_input[0]=='x'){
            cout<<"You entered x"<<endl;
            cout<<"Programm closed"<<endl;
            return false;
        }
        else{
            cout<<"Please enter a valid command {r,s,x}"<<endl;
        }
    }
    
    return 0;
}
