
#include <iostream>
#include <fstream>
#include <vector>
#include "second_subclass.h"
using namespace std;
#include <math.h> 

int second_subclass::getcount(){
    return count;
}
void second_subclass::setcount(int mycount){
    count =mycount;
}
///Getters and setters implementation
    int second_subclass::getx(){return x;}
    void second_subclass::setx(int thex){x=thex;}
    int second_subclass::gety(){return y;}
    void second_subclass::sety(int they){y=they;}
    int second_subclass::getw(){return w;}
    void second_subclass::setw(int thew){w=thew;}
    int second_subclass::getz(){return z;}
    void second_subclass::setz(int thez){z=thez;}


//Function to loop and generate results
void second_subclass::execute_instructions(vector<string> the_instructionsss,string user_input){
    
    //set variables to registers
    int x= getx();
    int y= gety();
    int w=getw();
    int z=getz();
    //int my_count=getcount();
    while(getcount()<the_instructionsss.size()){
        string my_expression = the_instructionsss[getcount()];
        //cout<<my_expression<<endl;
        //setcount(getcount()+1);
        //cout<<"This is my count  "<<getcount();
        //cout<<user_input[0]<<endl;
        
    
      
        //////////////////////////// WHEN ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ ///////////////////////////
        if (my_expression[3]=='='){
            if (my_expression[1]=='z'){
                  //cout<<"I'm here z"<<endl;
                if (my_expression[6]=='\0'){
                    int thevalue = my_expression[5] - '0';
                    setz(thevalue);
                }
                //////////////// When expression is of type x op num
                if(my_expression[5]=='x'){
                    
                  // cout<<" Im inside expression type z = x something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getx()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getx()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getx()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getx()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getx()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getx()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getx()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getx()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getx()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getx()-getw());
                        }
                        
                    }
                    
                    //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getx()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getx()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getx()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getx()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getx()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getx()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getx()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getx()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getx()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getx()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setz(pow(getx(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setz(pow(getx(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setz(pow(getx(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setz(pow(getx(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setz(pow(getx(),getw()));
                        }
                        
                    }
                    
                }
                //////////////// When expression is of type y op num
                if(my_expression[5]=='y'){
                    
                    
                    //cout<<" Im inside expression type z = y something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(gety()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(gety()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(gety()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(gety()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(gety()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(gety()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(gety()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(gety()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(gety()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(gety()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id / digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(gety()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(gety()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(gety()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(gety()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(gety()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(gety()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(gety()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(gety()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(gety()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(gety()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setz(pow(gety(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setz(pow(gety(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setz(pow(gety(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setz(pow(gety(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setz(pow(gety(),getw()));
                        }
                        
                    }
                   
                }
                  //////////////// When expression is of type z op num
                if(my_expression[5]=='z'){
                    //cout<<" Im inside expression type z = z something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getz()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getz()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getz()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getz()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getz()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getz()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getz()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getz()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getz()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getz()-getw());
                        }
                        
                    }
                    //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getz()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getz()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getz()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getz()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getz()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getz()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getz()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getz()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getz()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getz()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                        //cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setz(pow(getz(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setz(pow(getz(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setz(pow(getz(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setz(pow(getz(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setz(pow(getz(),getw()));
                        }
                        
                    }
                    
                    
                }
                //////////////// When expression is of type w op num
                 if(my_expression[5]=='w'){
                    // cout<<" Im inside expression type z = w something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getw()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getw()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getw()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getw()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getw()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getw()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getw()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getw()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getw()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getw()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getw()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getw()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getw()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getw()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getw()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setz(getw()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setz(getw()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setz(getw()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setz(getw()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setz(getw()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setz(pow(getw(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setz(pow(getw(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setz(pow(getw(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setz(pow(getw(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setz(pow(getw(),getw()));
                        }
                        
                    }
                    
                    
                }
                ///////////////////////////////////////
                if(user_input[0]=='s'){
                    cout<<"The expression being evaluated is "<<my_expression<< " which makes z = "<<getz()<< endl;
                    setcount(getcount()+1);
                   // user_input='\0';
                break;
                }
                
            }
            /////////////////////////////// WHEN XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX ///////////////////////////////
            else if (my_expression[1]=='x'){
                 // cout<<"I'm here x"<<endl;
                if (my_expression[6]=='\0'){
                    int thevalue = my_expression[5] - '0';
                    setx(thevalue);
                }
                //////////////// When expression is of type x op num
                if(my_expression[5]=='x'){
                    
                   
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                           
                            int secondval = my_expression[9]-'0';
                            setx(getx()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getx()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getx()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getx()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getx()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getx()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getx()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getx()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getx()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getx()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getx()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getx()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getx()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getx()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getx()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getx()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getx()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getx()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getx()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getx()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                        //cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setx(pow(getx(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setx(pow(getx(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setx(pow(getx(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setx(pow(getx(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setx(pow(getx(),getw()));
                        }
                        
                    }
                    
                }
                //////////////// When expression is of type y op num
                if(my_expression[5]=='y'){
                    
                    
                    //cout<<" Im inside expression type z = y something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(gety()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(gety()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(gety()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(gety()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(gety()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(gety()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(gety()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(gety()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(gety()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(gety()-getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(gety()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(gety()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(gety()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(gety()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(gety()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setx(pow(gety(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setx(pow(gety(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setx(pow(gety(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setx(pow(gety(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setx(pow(gety(),getw()));
                        }
                        
                    }
                   
                }
                  //////////////// When expression is of type z op num
                if(my_expression[5]=='z'){
                    //cout<<" Im inside expression type z = z something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getz()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getz()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getz()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getz()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getz()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getz()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getz()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getz()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getz()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getz()-getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getz()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getz()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getz()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getz()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getz()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                        //cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setx(pow(getz(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setx(pow(getz(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setx(pow(getz(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setx(pow(getz(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setx(pow(getz(),getw()));
                        }
                        
                    }
                    
                    
                }
                //////////////// When expression is of type w op num
                 if(my_expression[5]=='w'){
                     //cout<<" Im inside expression type z = w something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getw()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getw()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getw()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getw()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getw()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getw()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getw()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getw()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getw()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getw()-getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setx(getw()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setx(getw()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setx(getw()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setx(getw()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setx(getw()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                        //cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setx(pow(getw(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setx(pow(getw(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setx(pow(getw(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setx(pow(getw(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setx(pow(getw(),getw()));
                        }
                        
                    }
                    
                    
                }
                if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< " which makes x = "<<getx()<< endl;
                    setcount(getcount()+1);
                   // user_input='\0';
                break;
                }
                
            }
            ///////////////////////////////// WHEN YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY ////////////////////////////////
             else if (my_expression[1]=='y'){
                   //cout<<"I'm here y"<<endl;
                if (my_expression[6]=='\0'){
                    
                    int thevalue = my_expression[5] - '0';
                    sety(thevalue);
                }
                 /////////////////////////////////////////////////////////////////////////////////////
                 if(my_expression[5]=='x'){
                    
                  // cout<<" Im inside expression type z = x something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getx()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getx()+getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getx()+gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getx()+getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getx()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getx()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getx()-getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getx()-gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getx()-getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getx()-getw());
                        }
                        
                    }
                    
                    //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getx()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getx()/getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getx()/gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getx()/getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getx()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getx()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getx()*getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getx()*gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getx()*getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getx()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            sety(pow(getx(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            sety(pow(getx(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            sety(pow(getx(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            sety(pow(getx(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            sety(pow(getx(),getw()));
                        }
                        
                    }
                    
                }
                //////////////// When expression is of type y op num
                if(my_expression[5]=='y'){
                    
                    
                    //cout<<" Im inside expression type z = y something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(gety()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(gety()+getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(gety()+gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(gety()+getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(gety()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(gety()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(gety()-getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(gety()-gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(gety()-getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(gety()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id / digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(gety()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(gety()/getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(gety()/gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(gety()/getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(gety()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(gety()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(gety()*getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(gety()*gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(gety()*getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(gety()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            sety(pow(gety(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            sety(pow(gety(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            sety(pow(gety(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            sety(pow(gety(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            sety(pow(gety(),getw()));
                        }
                        
                    }
                   
                }
                  //////////////// When expression is of type z op num
                if(my_expression[5]=='z'){
                    //cout<<" Im inside expression type z = z something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getz()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getz()+getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getz()+gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getz()+getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getz()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getz()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getz()-getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getz()-gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getz()-getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getz()-getw());
                        }
                        
                    }
                    //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getz()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getz()/getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getz()/gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getz()/getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getz()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getz()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getz()*getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getz()*gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getz()*getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getz()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                        //cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            sety(pow(getz(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            sety(pow(getz(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            sety(pow(getz(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            sety(pow(getz(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            sety(pow(getz(),getw()));
                        }
                        
                    }
                    
                    
                }
                //////////////// When expression is of type w op num
                 if(my_expression[5]=='w'){
                    // cout<<" Im inside expression type z = w something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getw()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getw()+getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getw()+gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getw()+getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getw()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getw()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getw()-getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getw()-gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getw()-getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getw()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getw()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getw()/getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getw()/gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getw()/getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getw()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            sety(getw()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            sety(getw()*getx());
                        }
                        if (my_expression[9]=='y'){
                            sety(getw()*gety());
                        }
                        if (my_expression[9]=='z'){
                            sety(getw()*getz());
                        }
                        if (my_expression[9]=='w'){
                            sety(getw()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            sety(pow(getw(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            sety(pow(getw(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            sety(pow(getw(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            sety(pow(getw(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            sety(pow(getw(),getw()));
                        }
                        
                    }
                    
                    
                }
                 
                 /////////////////////////////////////////////////////////////////////////////////////////////////
                if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< " which makes y = "<<gety()<< endl;
                    setcount(getcount()+1);
                   // user_input='\0';
                break;
                }
                
            }
            ///////////////////////////////// WHEN WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW ////////////////////////////
             else if (my_expression[1]=='w'){
                   //cout<<"I'm here w"<<endl;
                if (my_expression[6]=='\0'){
                    int thevalue = my_expression[5] - '0';
                    setw(thevalue);
                }
                 /////////////////////////////////////////////////////////////////////////////////////////////////////
                 if(my_expression[5]=='x'){
                    
                  // cout<<" Im inside expression type z = x something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getx()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getx()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getx()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getx()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getx()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getx()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getx()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getx()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getx()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getx()-getw());
                        }
                        
                    }
                    
                    //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getx()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getx()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getx()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getx()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getx()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getx()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getx()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getx()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getx()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getx()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setw(pow(getx(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setw(pow(getx(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setw(pow(getx(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setw(pow(getx(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setw(pow(getx(),getw()));
                        }
                        
                    }
                    
                }
                //////////////// When expression is of type y op num
                if(my_expression[5]=='y'){
                    
                    
                    //cout<<" Im inside expression type z = y something "<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(gety()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(gety()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(gety()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(gety()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(gety()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(gety()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(gety()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(gety()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(gety()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(gety()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id / digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(gety()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(gety()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(gety()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(gety()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(gety()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(gety()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(gety()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(gety()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(gety()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(gety()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setw(pow(gety(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setw(pow(gety(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setw(pow(gety(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setw(pow(gety(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setw(pow(gety(),getw()));
                        }
                        
                    }
                   
                }
                  //////////////// When expression is of type z op num
                if(my_expression[5]=='z'){
                    //cout<<" Im inside expression type z = z something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getz()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getz()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getz()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getz()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getz()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getz()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getz()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getz()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getz()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getz()-getw());
                        }
                        
                    }
                    //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getz()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getz()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getz()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getz()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getz()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getz()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getz()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getz()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getz()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getz()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                        //cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setw(pow(getz(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setw(pow(getz(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setw(pow(getz(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setw(pow(getz(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setw(pow(getz(),getw()));
                        }
                        
                    }
                    
                    
                }
                //////////////// When expression is of type w op num
                 if(my_expression[5]=='w'){
                    //cout<<" Im inside expression type w = w something"<< endl;
                    //SUM
                    if(my_expression[7]=='+'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getw()+secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getw()+getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getw()+gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getw()+getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getw()+getw());
                        }
                    }
                
                      //Substraction
                    if(my_expression[7]=='-'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = (my_expression[9]-'0');
                          
                            setw(getw()-secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getw()-getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getw()-gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getw()-getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getw()-getw());
                        }
                        
                    }
                      //Division
                    if(my_expression[7]=='/'){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getw()/secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getw()/getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getw()/gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getw()/getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getw()/getw());
                        }
                        
                    }
                      //Multiplication
                    if(my_expression[7]=='*' && my_expression[8]==' '){
                        //case id + digit
                        if (isdigit(my_expression[9])==true){
                            int secondval = my_expression[9]-'0';
                            setw(getw()*secondval);
                        }
                        //case id+ id
                        if (my_expression[9]=='x'){
                            setw(getw()*getx());
                        }
                        if (my_expression[9]=='y'){
                            setw(getw()*gety());
                        }
                        if (my_expression[9]=='z'){
                            setw(getw()*getz());
                        }
                        if (my_expression[9]=='w'){
                            setw(getw()*getw());
                        }
                        
                    }
                    //Power
                    if(my_expression[7]=='*' && my_expression[8]=='*'){
                       // cout<<" Im inside expression type x** "<< endl;
                        //case id + digit
                        if (isdigit(my_expression[10])==true){
                            int secondval = my_expression[9]-'0';
                            setw(pow(getw(),secondval));
                        }
                        //case id+ id
                        if (my_expression[10]=='x'){
                            setw(pow(getw(),getx()));
                        }
                        if (my_expression[10]=='y'){
                            setw(pow(getw(),gety()));
                        }
                        if (my_expression[10]=='z'){
                            setw(pow(getw(),getz()));
                        }
                        if (my_expression[10]=='w'){
                            setw(pow(getw(),getw()));
                        }
                        
                    }
                    
                    
                }
                 ///////////////////////////////////////////////////////////////////////////////////////////////////
                if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< " which makes w = "<<getw()<< endl;
                    setcount(getcount()+1);
                   // user_input='\0';
                break;
                }
                
            }
            /////////////////////////////////////////// if nothing 
            
            
        
            
        }
        else{
            if(my_expression[3]=='?'){
                //////When starts with x
                
                if(my_expression[1]=='x'){
                    if(getx()!=0){
                        int secondval = my_expression[5]-'0';
                        cout<<"Register x is not equal to 0 count value changed to  "<<secondval<<endl;
                        setcount(secondval-1);
                        continue;
                        if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< endl;
                                break;
                                            }
                    }
                }
                
                //////When starts with y
                
                else if(my_expression[1]=='y'){
                    if(gety()!=0){
                        int secondval = my_expression[5]-'0';
                        cout<<"Register y is not equal to 0 count value changed to "<<secondval<<endl;
                        setcount(secondval-1);
                        continue;
                        if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< endl;
                                break;
                                            }
                    }
                }
                 //////When starts with w
                
                else if(my_expression[1]=='w'){
                    if(getw()!=0){
                        int secondval = my_expression[5]-'0';
                        cout<<"Register w is not equal to 0 count value changed to "<<secondval<<endl;
                        setcount(secondval-1);
                        continue;
                        if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< endl;
                                break;
                                            }
                    }
                }
                 //////When starts with z
                
                else if(my_expression[1]=='z'){
                    if(getz()!=0){
                        int secondval = my_expression[5]-'0';
                        cout<<"Register z is not equal to 0 count value changed to "<<secondval<<endl;
                        setcount(secondval-1);
                        continue;
                        if(user_input[0]=='s'){
                     cout<<"The expression being evaluated is "<<my_expression<< endl;
                                break;
                                            }
                    }
                }
            }
        }
                setcount(getcount()+1);
       
        
    }
     if (getcount()==the_instructionsss.size()){
            
            cout<< " You have reached the end"<<endl;
            cout << "These are the final results"<<endl;
            cout<<" X " <<getx()<<endl;
            cout<<" Y " <<gety()<<endl;
            cout<<" W " <<getw()<<endl;
            cout<<" Z " <<getz()<<endl<<endl;
         
        }
    

    
    
}
    
    