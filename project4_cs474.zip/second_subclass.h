#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include "first_subclass.h"
using namespace std;
#include <math.h> 
class second_subclass : public first_subclass{
    public:
    //My registers
    int x=0;
    int y=0;
    int w=0;
    int z=0;
    int count=0;
    string user_input;
    void execute_instructions(vector<string>, string user_input);
    int getcount();
    void setcount(int);
    //getters and setters for registers
    int getx();
    void setx(int);
    int gety();
    void sety(int);
    int getw();
    void setw(int);
    int getz();
    void setz(int);
    

    
};