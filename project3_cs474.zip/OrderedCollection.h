//
// University of Illinois at Chicago
// CS474 Project #3 -------- Fall 2021 ---------Ugo Buy
// Author: William Ernesto Escobar Morales
//

class OrderedCollection {
public:
    
/* 
 * Constructors for the class
 * default constructor
 * copy constructor
 * constructor taking an initial element for a new instance of ordered collecyion
*/
   OrderedCollection();
   OrderedCollection(const OrderedCollection&);
   OrderedCollection(int);
   
/* Destructor – You must make sure that no memory leaks will 
 * occur whenever an instance of OrderedCollection is deleted.
 */
   virtual ~OrderedCollection();
/*
 * isEmpty() – This method returns a boolean value indicating whether the receiver (an OrderedCollection
 * instance) contains no elements.
 */ 
    bool isEmpty(); 
/*
 * size() – This method returns the number of elements currently stored in the receiver. This could be different
 * (probably smaller) than the size of the allocated region.
 */
    int size();
/* 
 * basicSize() – This method returns the size of the contiguous region currently allocated to the receiver, not
 * the number of elements added to the receiver thus far.
 */  
    int basicSize();
/*
 * operator[](int) – The method takes as input an integer i and returns the i-th element 
 * in the receiver (an OrderedCollection instance). The first element in
 * the collection is numbered 0, corresponding to the element stored at position first and so on.
 */ 
    int& operator[](int);
/* 
 * This method takes as input two integers i and x (in that order). Integer x is inserted in
 * the receiver at index position i.
 */ 
    OrderedCollection& insertAt(int,int);
/*
 * This method takes as input an integer argument x. If x is contained in the receiver, it returns the
 * index position of x in the receiver. Otherwise it returns -1.
 */
    int find(int); 
/* 
 * Method to remove an element at position i
 */ 
    OrderedCollection& removeAt(int);
/*
 * This method applies the argument function fn to each element in the receiver.
 */ 
    OrderedCollection& iterate(int(*fn)(int)); 
/*
 * This method performs a deep copy of the right-hand size
 */ 
    OrderedCollection& operator=(const OrderedCollection&);      

//Method to manually inser elements into the array
   OrderedCollection& insert(int);

//Method to move elements from one side to another where side can be 1 or -1
 bool move_elements(int side, int start, int end);
//Protected methods and variables
protected:
   int first=4;//Variable that holds starting position of elements
   int last=3;//Variable that holds ending position of elements
   int mysize;//Varibale that holds the size of the array
   int basic_size;//Variable that holds the basic size of the array
   int * myarray; //Array variable that will hold the integer elements  
   void grow();   //Method to dinamically grow the array    
};
