# CS474 Project #3

### Running the file
OrderedCollection.h contains functions declarations
OrderedCollection.cpp contains functions definitions
main.cpp is a file where one can use the functions in OrderedCollection

### Compile, Run or Both
I used codio to create and run my code

To Test the functions edit the main file
