//
// University of Illinois at Chicago
// CS474 Project #3 -------- Fall 2021 ---------Ugo Buy
// Author: William Ernesto Escobar Morales
//

#include "OrderedCollection.h"
#include <iostream>

/*
* Constructors
*/
OrderedCollection::OrderedCollection() {
   first = 4;
   last = 4;
   mysize = 0;
   basic_size = 8;
   myarray = new int[8];
   for (int i = 0; i < basic_size; ++i) {
       myarray[i] = 0;
   }
}
OrderedCollection::OrderedCollection(const OrderedCollection& other) {
   first = other.first;
   last = other.last;
   mysize = other.mysize;
   basic_size = other.basic_size;
   myarray = new int[basic_size];
   for (int i = 0; i < basic_size; ++i) {
       myarray[i] = other.myarray[i];
   }
}

OrderedCollection::OrderedCollection(int x) {
   first =4;
   last = 4;
   mysize = 0;
   basic_size = 8;
   myarray = new int[8];
   for (int i = 0; i < basic_size; ++i) {
       myarray[i] = 0;
   }
   insertAt(1,x);
}


/*
* Destructor
*/
OrderedCollection::~OrderedCollection() {
   delete[] myarray;
}

/*
* Methods
*/
OrderedCollection & OrderedCollection::operator =(const OrderedCollection& right_side){
   if(this != &right_side){
       first = right_side.first;
       last = right_side.last;
       mysize = right_side.mysize;
       basic_size = right_side.basic_size;
       delete[] myarray;
       myarray = new int[basic_size];
       for (int i = 0; i < basic_size; ++i) {
           myarray[i] = right_side.myarray[i];
       }
   }
   return *this;
}

/*
* public Methods
*/

bool OrderedCollection::isEmpty(){
   return (mysize == 0);
} 

int OrderedCollection::size(){
   return mysize;
}

int OrderedCollection::basicSize(){
   return basic_size;
}

int & OrderedCollection::operator[](int index){
   if (index < 1 || index + first > last) {
       std::cout << "Index does not exists" << std::endl;
   }
   else{
       return myarray[index + first - 1];
   }
}

bool OrderedCollection::move_elements(int side, int start, int end){
   if(side == -1){ 
       if(myarray[0] == 0){
           for (int i = first + start - 1; i <= first + end; ++i) {
               myarray[i - 1] = myarray[i];
           }
       }
       else{
           return false;
       }
   }
   else
   if(side == 1){
       if(first+end != basic_size && myarray[first+end] == 0){
           for (int i = first + end - 1; i >= 0 + start; --i) {
               myarray[i + 1] = myarray[i];
           }
       }
       else{
           return false;
       }
   }
   return true;
}

OrderedCollection& OrderedCollection::insertAt(int i, int x){
    //checking if the index is not out of bounds
   if (i < 1 || i + first > last + 1) {
       std::cout << "Index does not exists" << std::endl;
       return *this;
   }
   i--; 
//When inserting an elemenent with the inserAt function we must check in to what direction we are
//going to move the array to not lose any of the elemenents
   if(myarray[first + i] == 0 && first + mysize != basic_size){
       myarray[first + i] = x;
       last++;
   }
   else{
       if(first + i - 1 >= 0 && myarray[first + i - 1] == 0){
           myarray[first + i - 1] = x;
           first--;
       }
       else{
           bool move = false;
           if(i < basic_size/2){
               move = move_elements(-1,1,i);
               if(move){
                   first--;
                   last--;
               }
           }
           if(!move && first > i){
               move = move_elements(1,i,mysize);
               if(move){
                   first++;
                   last++;
               }
           }
           if(!move){
               if(first > i){
                   if(myarray[basic_size - 1] == 0){
                   int count = 0;
                   while(myarray[basic_size - 1] == 0){
                    for (int i = basic_size -1; i >= 0; --i) {
                        if(i!= 0)
                         myarray[i] = myarray[i - 1];
                     else
                    myarray[i] = 0;
                    }
                    count++;
                    first++;
                    last++;
                    }

                }
            else{
       move= false;
        }

                move= true;
               }
               else{
                   if(basic_size - mysize >= last - i)
                       if(myarray[0] == 0){
                           int count = 0;
                           while(myarray[0] == 0){
                            for (int i = 0; i < basic_size; ++i) {
                            myarray[i] = myarray[i + 1];
                             }
                            count++;
                            first--;
                            last--;
                            }
                    }
                    else{
                            move =false;
                        }
                    move =true;
               }
           }
           if(move){
               myarray[first + i] = x;
               last++;
           }
           else{
               grow();
               if(first + i - 1 >= 0 && myarray[first + i - 1] == 0){
                   myarray[first + i - 1] = x;
                   first--;
               }
               else
               if(myarray[first + i] == 0 && first + mysize != basic_size){
                   myarray[first + i] = x;
                   last++;
               }
               else{
                   if(i < basic_size/2){
                       move = move_elements(-1,1,i);
                       first--;
                       last--;
                   }
                   else{
                       move = move_elements(1,i,mysize);
                       first++;
                       last++;
                   }
                   }
                   if(move){
                       myarray[first + i] = x;
                       last++;
                   }
               }
           }
       }
    mysize++;
   return *this;
   }
   

//function to manually add elements in the array 
OrderedCollection& OrderedCollection::insert(int x){
   int pos = 1;
   if(mysize != 0)
       pos = (rand() % mysize) + 1;
   return insertAt(pos, x);
}

int OrderedCollection::find(int x){
   for (int i = first; i < last + 1; ++i) {
       if(myarray[i] == x)
           return i - first + 1;
   }
   return -1;
}

OrderedCollection& OrderedCollection::removeAt(int i){
   if (i < 1 || i + first > last + 1) {
       std::cout << "Index does not exists" << std::endl;
       return *this;
   }
   i--;   
   myarray[first + i] = 0;
   if(i == 0){
       first++;
   }
   else{
       if(i == mysize - 1){
           last--;
       }else{
       if(i < mysize/2){
           move_elements(1,1,i);
           first++;
       }
       else{
           move_elements(-1,i,mysize);
           last--;
       }
       }
   }
   mysize--;
   return *this;
}

OrderedCollection& OrderedCollection::iterate(int (*fn)(int)){
   for (int i = first; i < last; ++i) {
       myarray[i] = fn(myarray[i]);
   }
   return *this;
}


void OrderedCollection::grow(){
   int * new_arr = new int[basic_size * 2];//doubling the size of the array
   int counter = 0;
   int new_start = (basic_size * 2)/4;
   for (int i = first; i < last; ++i) {
       new_arr[new_start + counter] = myarray[i];
       counter++;
   }
   delete[] myarray;
   myarray = new_arr;
   first = new_start;
   last = first + mysize;
   basic_size = basic_size * 2;
  
}


