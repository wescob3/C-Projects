//
// University of Illinois at Chicago
// CS474 Project #3 -------- Fall 2021 ---------Ugo Buy
// Author: William Ernesto Escobar Morales
//
//
//You can used the instance of the object class to test the rest of the functions
//
#include <iostream>
#include <fstream>
#include <string>

#include "OrderedCollection.cpp"

using namespace std;

int main(){
    OrderedCollection myarray;
    cout<<endl;
    cout<<"Welcome to my OrderedCollection  "<<endl<<endl;
    cout<<"My ordered Collection starting size is "<<myarray.size()<<endl<<endl;
    
    cout<<"Adding elements into our OrderedCollection "<<endl;
    //Adding 5 elements to our ordered collection
    myarray.insert(5);
    myarray.insert(15);
    myarray.insert(25);
    myarray.insert(35);
    myarray.insert(45);
    
    cout<<"My new orderedCollection size is "<<myarray.size()<<endl<<endl;
    
    cout<<"Is 5 in the orderedCollection? "<<myarray.find(5)<<endl;
    cout<<"Is 7 in the orderedCollection? "<<myarray.find(7)<<endl;
    
    cout<<"Inserting 10 at position 5"<<endl;
    myarray.insertAt(5,10);
    
    cout<<"My new orderedCollection size is "<<myarray.size()<<endl<<endl;
    
    return 0;
}